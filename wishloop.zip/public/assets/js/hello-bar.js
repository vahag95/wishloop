function wl_hb_close () {
	var wl_hb_cont = document.getElementById( 'wl-hb-cont' );
	wl_hb_cont.parentNode.removeChild( wl_hb_cont );
}