function wl_tg_close () {
	var wl_tg_cont = document.getElementById( 'wl-tg-cont' );
	wl_tg_cont.parentNode.removeChild( wl_tg_cont );
}