<?php 

return [
	'aweber' => [
		'consumer_key' => 'Ak93deBcfbUqwrLBCr18C4cZ',
		'consumer_secret' => 'sqCIdRpBtfHY7Zt65fv3nHMn2uzcNNGjaVzqT7a5'
	]
	
];