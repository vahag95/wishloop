<?php

// You can find the keys here : https://apps.twitter.com/

return [
	'debug'               => false,

	'API_URL'             => 'api.twitter.com',
	'UPLOAD_URL'          => 'upload.twitter.com',
	'API_VERSION'         => '1.1',
	'AUTHENTICATE_URL'    => 'https://api.twitter.com/oauth/authenticate',
	'AUTHORIZE_URL'       => 'https://api.twitter.com/oauth/authorize',
	'ACCESS_TOKEN_URL'    => 'https://api.twitter.com/oauth/access_token',
	'REQUEST_TOKEN_URL'   => 'https://api.twitter.com/oauth/request_token',
	'USE_SSL'             => true,

	'CONSUMER_KEY'        => '8HsS4gp5tZTe4B0gn6cZJczyw',
	'CONSUMER_SECRET'     => 'jCeMLKq5BSQW3EeILq6XcV2da1yfiacMlldz9bQlH9xu9Sgvbx',
	'ACCESS_TOKEN'        => '4462148818-stGX8wwnWVr2i8G0G9hqeVq6lX1CibGGVJPmI9C',
	'ACCESS_TOKEN_SECRET' => 'oDCD1RwHIatH7aV9orDYT5DNY2PlLfSOLeQ7rxQYRP680'
];
