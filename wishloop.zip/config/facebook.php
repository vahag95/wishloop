<?php 

return [	
		'app_id' => '625833234222108',
        'app_secret' => 'b7e9e0c385c87de911ec7dbda67f955d',
        'default_graph_version' => 'v2.5',
        'persistent_data_handler'=>'session'
];