<?php

namespace App\Contracts;

interface HelloBarClicksServiceInterface {	
	public function addClick($id);
}