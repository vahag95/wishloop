<?php

namespace App\Contracts;

interface TrafficGenerationClicksServiceInterface {	
	public function addClick($id);
}